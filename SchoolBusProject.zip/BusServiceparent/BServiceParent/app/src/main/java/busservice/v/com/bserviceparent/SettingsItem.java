package busservice.vv.com.bserviceparent;

public class SettingsItem {
    private String title;

    SettingsItem(String tittle){
        this.title = tittle;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

}