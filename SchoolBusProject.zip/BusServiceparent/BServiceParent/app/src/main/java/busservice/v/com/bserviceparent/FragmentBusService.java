package busservice.vv.com.bserviceparent;

import android.Manifest;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.sqlite.SQLiteException;
import android.net.Uri;
import android.os.Bundle;
import android.app.Fragment;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.couchbase.lite.Database;

import java.util.Map;


import busservice.vv.com.bserviceparent.db.Application;
import busservice.vv.com.bserviceparent.db.Bus;
import busservice.vv.com.bserviceparent.db.Student;


public class FragmentBusService extends Fragment implements View.OnClickListener{

    private static final int MY_PERMISSIONS_REQUEST_CALL_PHONE = 0;
    private static final int MY_PERMISSIONS_REQUEST_READ_SMS = 1;
    private int currentStop=1;
    private boolean[] attendance;
    private String students[];
    private Map<String, String> studList;

    public FragmentBusService() {
        // Required empty public constructor

    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_bus, container, false);
    }


    @Override
    public void onDetach() {
        super.onDetach();
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        TextView settingTV = (TextView) view.findViewById(R.id.settingsTitle);
        settingTV.setOnClickListener(this);
        ImageView settingIV = (ImageView) view.findViewById(R.id.settingsImg);
        settingIV.setOnClickListener(this);

        TextView busOnMapTitleTV = (TextView) view.findViewById(R.id.busOnMap);
        busOnMapTitleTV.setOnClickListener(this);
        ImageView busOnMapIV = (ImageView) view.findViewById(R.id.busOnMapImg);
        busOnMapIV.setOnClickListener(this);

        TextView calBusTV = (TextView) view.findViewById(R.id.calBusTitle);
        calBusTV.setOnClickListener(this);
        ImageView calBusIV = (ImageView) view.findViewById(R.id.calBusImg);
        calBusIV.setOnClickListener(this);

        studList = Student.getStudentsMap(getDatabase());
        students = new String[studList.size()];
        attendance = new boolean[studList.size()];
        int i=0;
        for(Map.Entry<String,String> studEntry : studList.entrySet()){
            students[i]=studEntry.getKey();
            i++;
        }

    }

    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.settingsImg:
            case R.id.settingsTitle:
                FragmentManager fragmentManager = getFragmentManager();
                FragmentTransaction fts = fragmentManager.beginTransaction();
                fts.addToBackStack("servicToSettings");
                fts.replace(R.id.content, new SettingsFragment());
                fts.commit();
                break;

            case R.id.busOnMap:
            case R.id.busOnMapImg:
                requestOpenMap();
                break;

            case R.id.calBusTitle:
            case R.id.calBusImg:
                String busNum = Bus.getBusNUmber(getDatabase());
                if(busNum .isEmpty()){
                    Toast.makeText(getActivity(),"Please Add Bus number",Toast.LENGTH_LONG).show();
                }else{
                   requestCallPermission(busNum);
                }
                break;
        }
    }


    private void requestCallPermission(String busNum){
        if (ContextCompat.checkSelfPermission(getActivity(),Manifest.permission.CALL_PHONE)!= PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(getActivity(),new String[]{Manifest.permission.CALL_PHONE}, MY_PERMISSIONS_REQUEST_CALL_PHONE);
            return;
        }
        placeCall(busNum);

    }

    private void placeCall(String busNum){
        Intent callIntent = new Intent(Intent.ACTION_CALL);
        callIntent.setData(Uri.parse("tel:"+busNum));
        startActivity(callIntent);
    }

    private Database getDatabase() {
        Application application = (Application) getActivity().getApplication();
        return application.getDatabase();
    }


    private void requestOpenMap(){
        if (ContextCompat.checkSelfPermission(getActivity(),Manifest.permission.READ_SMS)!= PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(getActivity(),new String[]{Manifest.permission.READ_SMS}, MY_PERMISSIONS_REQUEST_READ_SMS);
            return;
        }
        openMap();
    }

    private void openMap() {
        final String SMS_URI_INBOX = "content://sms/inbox";
        try {
            String busNum = Bus.getBusNUmber(getDatabase());
            Uri uri = Uri.parse(SMS_URI_INBOX);
            String[] projection = new String[]{"_id", "address", "person", "body", "date", "type"};
            Cursor cur = getActivity().getContentResolver().query(uri, projection, "address='"+busNum+"'", null, "date desc");
            if (cur!=null && cur.moveToFirst()) {
                String msgBody = cur.getString(cur.getColumnIndex("body"));

                if(msgBody.contains("Latitude") && msgBody.contains("Longitude")){
                    String[] la = msgBody.substring(msgBody.indexOf("Latitude:"), msgBody.indexOf("Longitude:")-2).split(":");
                    String[] lo = msgBody.substring(msgBody.indexOf("Longitude:")).split(":");

                    String latitude = la[1];
                    String longitude = lo[1];

                    if (!cur.isClosed()) {
                        cur.close();
                        cur = null;
                    }

                    String coordinates = String.format("geo:0,0?q=" + latitude + "," + longitude);
                    Intent intentMap = new Intent( Intent.ACTION_VIEW, Uri.parse(coordinates) );
                    startActivity( intentMap );
                }else{
                    Toast.makeText(getActivity(),"Latest message donot contain co-ordinates",Toast.LENGTH_LONG).show();
                }
            } else {
                Toast.makeText(getActivity(),"Message not recieved yet",Toast.LENGTH_LONG).show();
            } // end if
        } catch (SQLiteException ex) {
            Log.d("SQLiteException", ex.getMessage());
        }
    }
}
