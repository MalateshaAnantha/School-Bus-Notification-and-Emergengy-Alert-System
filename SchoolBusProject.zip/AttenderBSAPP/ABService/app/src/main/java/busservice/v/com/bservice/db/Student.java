package busservice.vv.com.bservice.db;

import com.couchbase.lite.CouchbaseLiteException;
import com.couchbase.lite.Database;
import com.couchbase.lite.Document;
import com.couchbase.lite.Emitter;
import com.couchbase.lite.Mapper;
import com.couchbase.lite.Query;
import com.couchbase.lite.QueryEnumerator;
import com.couchbase.lite.QueryRow;
import com.couchbase.lite.util.Log;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Student {
    private static final String VIEW_NAME = "student";
    private static final String DOC_TYPE = "student";

    public static Query getQuery(Database database) {
        com.couchbase.lite.View view = database.getView(VIEW_NAME);
        if (view.getMap() == null) {
            Mapper mapper = new Mapper() {
                public void map(Map<String, Object> document, Emitter emitter) {
                    String type = (String)document.get("type");
                    if (DOC_TYPE.equals(type)) {
                        emitter.emit(document.get("student_name"), document);
                    }
                }
            };
            view.setMap(mapper, "1");
        }

        Query query = view.createQuery();
        query.setDescending(true);
        return query;
    }

    public static Document addStudent(Database database,
                                           String studentName,
                                           String rollNumber,
                                           String parentPhNum,
                                           String stopName) throws CouchbaseLiteException {
        SimpleDateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
        Calendar calendar = GregorianCalendar.getInstance();
        String currentTimeString = dateFormatter.format(calendar.getTime());

        Map<String, Object> properties = new HashMap<String, Object>();
        properties.put("type", DOC_TYPE); //student
        properties.put("student_name", studentName); //Rajath
        properties.put("created_at", currentTimeString); //some time
        properties.put("student_id", rollNumber); // student roll number
        properties.put("parent_ph_num", parentPhNum);
        properties.put("stop_name", stopName);
        properties.put("attendance",new ArrayList<String>());

        Document document = database.createDocument();
        document.putProperties(properties);

        Log.d(Application.TAG, "Created doc: %s", document.getId());

        return document;
    }

    public static void removeStudent(Document student) throws CouchbaseLiteException {
        Log.d(Application.TAG, "Deleted doc: %s", student.getId());
        student.delete();
    }

    public static void removeStudent(Database database,String studentName) throws CouchbaseLiteException {
        try {
            QueryEnumerator enumerator = getQuery(database).run();
            Document toDelete = null;
            for(QueryRow row : enumerator){
                if(studentName.equals(row.getDocument().getProperty("student_name"))){
                    toDelete = row.getDocument();
                }
            }
            toDelete.delete();
        } catch (CouchbaseLiteException e) {
            e.printStackTrace();
        }

        Log.d(Application.TAG, "Deleted " + studentName);
    }

    public static List<String> getStudents(Database database){
        List<String> studentList = new ArrayList<String>();
        try {
            QueryEnumerator enumerator = getQuery(database).run();

            for(QueryRow row : enumerator){
                studentList.add((String) row.getDocument().getProperty("student_name"));
            }

        } catch (CouchbaseLiteException e) {
            e.printStackTrace();
        }
        return studentList;
    }


    public static void updateStudentAttendance(Database database, String student_id)
            throws CouchbaseLiteException {
        Document student = database.getDocument(student_id);

        SimpleDateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
        Calendar calendar = GregorianCalendar.getInstance();
        String currentTimeString = dateFormatter.format(calendar.getTime());

        List<String> attendance = (List)student.getProperty("attendance");
        attendance.add(currentTimeString);

        Map<String, Object> properties = new HashMap<String, Object>();
        properties.putAll(student.getProperties());
        properties.put("attendance", attendance);
        student.putProperties(properties);
    }

    public static Map<String, String> getStudentsMap(Database database){
        Map<String,String> studentList = new HashMap<>();
        try {
            QueryEnumerator enumerator = getQuery(database).run();

            for(QueryRow row : enumerator){
                Document doc = row.getDocument();

                studentList.put((String) doc.getProperty("student_name"), doc.getId());
            }

        } catch (CouchbaseLiteException e) {
            e.printStackTrace();
        }
        return studentList;
    }

    public static List<String> getStudentParentNum(Database database){
        List<String> phNumList = new ArrayList<String>();
        try {
            QueryEnumerator enumerator = getQuery(database).run();

            for(QueryRow row : enumerator){
                phNumList.add((String) row.getDocument().getProperty("parent_ph_num"));
            }

        } catch (CouchbaseLiteException e) {
            e.printStackTrace();
        }
        return phNumList;
    }

    public static List<String> getStudentParentNum(Database database,String stopName){
        List<String> studentList = new ArrayList<>();
        try {
            QueryEnumerator enumerator = getQuery(database).run();

            for(QueryRow row : enumerator){
                if(stopName.equals(row.getDocument().getProperty("stop_name"))){
                    studentList.add((String) row.getDocument().getProperty("parent_ph_num"));
                }
            }

        } catch (CouchbaseLiteException e) {
            e.printStackTrace();
        }
        return studentList;
    }

}
