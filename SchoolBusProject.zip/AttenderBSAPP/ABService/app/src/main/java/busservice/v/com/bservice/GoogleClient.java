package busservice.vv.com.bservice;

import android.content.Context;
import android.os.Bundle;
import android.support.annotation.NonNull;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.location.LocationServices;

public class GoogleClient {

    private static GoogleApiClient mGoogleApiClient;

    private void GoogleClient(){
    }

    public static GoogleApiClient getInstance(Context context){
        if (mGoogleApiClient == null) {
            mGoogleApiClient = new com.google.android.gms.common.api.GoogleApiClient.Builder(context)
                    .addConnectionCallbacks(new com.google.android.gms.common.api.GoogleApiClient.ConnectionCallbacks() {
                        @Override
                        public void onConnected(Bundle bundle) {
                            //Toast.makeText(getActivity(), "Connected", Toast.LENGTH_SHORT).show();
                        }

                        @Override
                        public void onConnectionSuspended(int i) {

                        }
                    })
                    .addOnConnectionFailedListener(new com.google.android.gms.common.api.GoogleApiClient.OnConnectionFailedListener() {
                        @Override
                        public void onConnectionFailed(@NonNull ConnectionResult connectionResult) {
                            //Toast.makeText(context, "Coonection failed", Toast.LENGTH_LONG).show();
                        }
                    })
                    .addApi(LocationServices.API)
                    .build();
        }

        return  mGoogleApiClient;
    }


}
