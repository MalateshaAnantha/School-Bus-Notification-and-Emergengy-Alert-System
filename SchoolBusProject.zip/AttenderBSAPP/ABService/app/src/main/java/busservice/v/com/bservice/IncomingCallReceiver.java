package busservice.vv.com.bservice;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.telephony.PhoneStateListener;
import android.telephony.TelephonyManager;
import android.widget.Toast;

import com.android.internal.telephony.ITelephony;

public class IncomingCallReceiver extends BroadcastReceiver {
    private ITelephony telephonyService;
    //private String blacklistednumber = "+919844492259";

    public void onReceive(Context context, Intent intent) {
        Toast.makeText(context, "SMS Call", Toast.LENGTH_LONG).show();
        //Create object of Telephony Manager class.
        TelephonyManager telephony = (TelephonyManager)  context.getSystemService(Context.TELEPHONY_SERVICE);
        //Assign a phone state listener.
        CustomPhoneStateListener customPhoneListener = new CustomPhoneStateListener (context);
        telephony.listen(customPhoneListener, PhoneStateListener.LISTEN_CALL_STATE);
    }
}

