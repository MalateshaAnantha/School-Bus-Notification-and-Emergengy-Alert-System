package busservice.vv.com.bservice;

import android.content.Context;
import android.os.Bundle;
import android.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.couchbase.lite.Database;

import java.util.ArrayList;
import java.util.List;

import busservice.vv.com.bservice.db.Application;

public class SettingsFragment extends Fragment implements  SettingsListAdapter.OnItemClickListener{

    private RecyclerView mRecyclerView;
    private RecyclerView.Adapter mAdapter;
    private RecyclerView.LayoutManager mLayoutManager;
    private List<SettingsItem> feedsList;

    public SettingsFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.setting_fragment, container, false);
        mRecyclerView = (RecyclerView) view.findViewById(R.id.settingList);
        mRecyclerView.setHasFixedSize(true);

        mLayoutManager = new LinearLayoutManager(getActivity());
        mRecyclerView.setLayoutManager(mLayoutManager);

        feedsList = new ArrayList();
        feedsList.add(new SettingsItem("Add Student"));
        feedsList.add(new SettingsItem("Remove Student"));
        feedsList.add(new SettingsItem("Add Bus Number"));
        feedsList.add(new SettingsItem("Change Bus Number"));
        feedsList.add(new SettingsItem("Add Student from File"));

        mAdapter = new SettingsListAdapter(getActivity(), feedsList,getDatabase());
        mRecyclerView.setAdapter(mAdapter);
        return view;
    }

    protected void onAttachToContext(Context context) {
    }


    @Override
    public void onViewCreated(final View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);



    }

    @Override
    public void onItemClick(View view, int position) {

    }

    private Database getDatabase() {
        Application application = (Application) getActivity().getApplication();
        return application.getDatabase();
    }

}
