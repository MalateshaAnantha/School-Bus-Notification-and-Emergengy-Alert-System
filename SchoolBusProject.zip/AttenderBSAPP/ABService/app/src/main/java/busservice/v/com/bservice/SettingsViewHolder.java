package busservice.vv.com.bservice;

import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;

public class SettingsViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
    protected TextView textView;
    private ClickListener clickListener;

        public SettingsViewHolder(View view) {
            super(view);
            this.textView = (TextView) view.findViewById(R.id.settingitem);
            view.setOnClickListener(this);
        }




    public interface ClickListener {
        public void onClick(View v, int position, boolean isLongClick);
    }

    public void setClickListener(ClickListener clickListener) {
        this.clickListener = clickListener;
    }

    @Override
    public void onClick(View view) {
        // If long clicked, passed last variable as true.
        clickListener.onClick(view, getAdapterPosition(), true);
    }
}