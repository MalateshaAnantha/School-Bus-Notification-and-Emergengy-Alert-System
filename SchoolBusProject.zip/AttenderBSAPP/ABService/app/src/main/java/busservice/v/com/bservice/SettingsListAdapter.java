package busservice.vv.com.bservice;

import android.annotation.TargetApi;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Build;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.couchbase.lite.CouchbaseLiteException;
import com.couchbase.lite.Database;
import com.couchbase.lite.Document;

import java.util.Arrays;
import java.util.List;

import busservice.vv.com.bservice.db.Application;
import busservice.vv.com.bservice.db.Bus;
import busservice.vv.com.bservice.db.Student;

public class SettingsListAdapter extends RecyclerView.Adapter<SettingsViewHolder> implements View.OnClickListener{
    private final Database database;
    private List<SettingsItem> settingsItemList;
    private Context mContext;
    private String mStudentSelected="";
    private String mStopSelected = "";

    private OnItemClickListener onItemClickListener;


    public SettingsListAdapter(Activity activity, List<SettingsItem> settingsItemList, Database database) {
        this.settingsItemList = settingsItemList;
        this.mContext = activity;
        this.database = database;
    }

    @Override
    public SettingsViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.settings_list_cell, null);

        SettingsViewHolder viewHolder = new SettingsViewHolder(view);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(SettingsViewHolder settingsViewHolder, int i) {
        SettingsItem settingsItem = settingsItemList.get(i);

        //Setting text view title
        settingsViewHolder.textView.setTag(i);
        settingsViewHolder.textView.setText(settingsItem.getTitle());

        settingsViewHolder.setClickListener(new SettingsViewHolder.ClickListener() {
            @TargetApi(Build.VERSION_CODES.LOLLIPOP)
            @Override
            public void onClick(View v, int position, boolean isLongClick) {

                LayoutInflater inflator = LayoutInflater.from(v.getContext());
                switch (position) {
                    case 0: //Add Student
                        final View view = inflator.inflate(R.layout.add_student, null);

                        Spinner stopSpinner = (Spinner) view.findViewById(R.id.stopList);
                        ArrayAdapter<String> ada = new ArrayAdapter<String>(mContext,
                                android.R.layout.simple_spinner_item, Arrays.asList("Stop 1", "Stop 2", "Stop 3", "Stop 4", "Stop 5"));
                        // Specify the layout to use when the list of choices appears
                        ada.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        // Apply the adapter to the spinner
                        stopSpinner.setAdapter(ada);
                        stopSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                            @Override
                            public void onItemSelected(AdapterView<?> adapterView, View view, int pos, long l) {
                                mStopSelected = (String) adapterView.getItemAtPosition(pos);
                            }

                            @Override
                            public void onNothingSelected(AdapterView<?> adapterView) {

                            }
                        });

                        AlertDialog.Builder addStubuilder = new AlertDialog.Builder(v.getContext());
                        addStubuilder.setTitle("Add Student")
                                .setView(view)
                                .setPositiveButton("Add", new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int id) {

                                        EditText sN = (EditText) view.findViewById(R.id.studentName);
                                        EditText sRN = (EditText) view.findViewById(R.id.studentRollNumber);
                                        EditText pPN = (EditText) view.findViewById(R.id.parentPhNum);
                                        //EditText stopN = (EditText)view.findViewById(R.id.stopName);
                                        try {
                                            Document doc = Student.addStudent(database, sN.getText().toString(),
                                                    sRN.getText().toString(),
                                                    pPN.getText().toString(),
                                                    mStopSelected);

                                            Toast.makeText(mContext, sN.getText().toString() + " created", Toast.LENGTH_LONG).show();

                                        } catch (CouchbaseLiteException e) {
                                            Log.e(Application.TAG, "Cannot add student", e);
                                        }
                                    }
                                })
                                .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int id) {
                                        // User cancelled the dialog
                                    }
                                });
                        addStubuilder.create().show();
                        break;
                    case 1: //Remove Student

                        final View rsView = inflator.inflate(R.layout.remove_student, null);
                        Spinner spinner = (Spinner) rsView.findViewById(R.id.studentList);
                        // Create an ArrayAdapter using the string array and a default spinner layout
                        ArrayAdapter<String> adapter = new ArrayAdapter<String>(mContext,
                                android.R.layout.simple_spinner_item, Student.getStudents(database));
                        // Specify the layout to use when the list of choices appears
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        // Apply the adapter to the spinner
                        spinner.setAdapter(adapter);
                        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                            @Override
                            public void onItemSelected(AdapterView<?> adapterView, View view, int pos, long l) {
                                mStudentSelected = (String) adapterView.getItemAtPosition(pos);
                            }

                            @Override
                            public void onNothingSelected(AdapterView<?> adapterView) {

                            }
                        });

                        AlertDialog.Builder remoStubuilder = new AlertDialog.Builder(v.getContext());
                        remoStubuilder.setTitle("Remove Student")
                                .setView(rsView)
                                .setPositiveButton("Remove", new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int id) {

                                        try {
                                            Student.removeStudent(database, mStudentSelected);

                                            Toast.makeText(mContext, mStudentSelected + " Deleted", Toast.LENGTH_LONG).show();

                                        } catch (CouchbaseLiteException e) {
                                            Log.e(Application.TAG, "Cannot add student", e);
                                        }
                                    }
                                })
                                .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int id) {
                                        // User cancelled the dialog
                                    }
                                });
                        remoStubuilder.create().show();
                        break;
                    case 2: //Add Bus number
                        final View busView = inflator.inflate(R.layout.bus_number, null);

                        AlertDialog.Builder busNumbuilder = new AlertDialog.Builder(v.getContext());
                        busNumbuilder.setTitle("Add Bus Phone Number")
                                .setView(busView)
                                .setPositiveButton("Add", new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int id) {

                                        EditText busPhNum = (EditText) busView.findViewById(R.id.busPhNum);
                                        try {
                                            Bus.addBus(database, busPhNum.getText().toString());

                                            Toast.makeText(mContext, busPhNum.getText().toString() + " Added", Toast.LENGTH_LONG).show();

                                        } catch (CouchbaseLiteException e) {
                                            Log.e(Application.TAG, "Cannot add student", e);
                                        }
                                    }
                                })
                                .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int id) {
                                        // User cancelled the dialog
                                    }
                                });
                        busNumbuilder.create().show();
                        break;
                    case 3: //Change Bus number
                        final View busChView = inflator.inflate(R.layout.bus_number, null);

                        AlertDialog.Builder busChNumbuilder = new AlertDialog.Builder(v.getContext());
                        busChNumbuilder.setTitle("Add Bus Phone Number")
                                .setView(busChView)
                                .setPositiveButton("Add", new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int id) {

                                        EditText busPhNum = (EditText) busChView.findViewById(R.id.busPhNum);
                                        try {
                                            if (Bus.updateBusNumber(database, busPhNum.getText().toString())) {
                                                Toast.makeText(mContext, busPhNum.getText().toString() + " Added", Toast.LENGTH_LONG).show();
                                            } else {
                                                Toast.makeText(mContext, "Bus number not present to change ", Toast.LENGTH_LONG).show();
                                            }


                                            Toast.makeText(mContext, busPhNum.getText().toString() + " Added", Toast.LENGTH_LONG).show();

                                        } catch (CouchbaseLiteException e) {
                                            Log.e(Application.TAG, "Cannot add student", e);
                                        }
                                    }
                                })
                                .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int id) {
                                        // User cancelled the dialog
                                    }
                                });
                        busChNumbuilder.create().show();
                        break;
                    case 4: //Add student from file
                        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                        intent.setType("file/*");
                        intent.addCategory(Intent.CATEGORY_OPENABLE);
                        try {
                            ((Activity)mContext).startActivityForResult(intent, 01);
                        } catch (android.content.ActivityNotFoundException ex) {
                            // Potentially direct the user to the Market with a Dialog
                            Toast.makeText(mContext, "Please install a File Manager.",Toast.LENGTH_SHORT).show();
                        }

                       /* new FileChooser((Activity) mContext).setFileListener(new FileChooser.FileSelectedListener() {
                            @Override public void fileSelected(final File file) {
                                Toast.makeText(mContext, "File -" +file.getAbsolutePath(),Toast.LENGTH_SHORT).show();
                            }}).showDialog();*/

                        break;
                }
            }
        });
    }




    @Override
    public int getItemCount() {
        return (null != settingsItemList ? settingsItemList.size() : 0);
    }


    @Override
    public void onClick(View view) {
        if (onItemClickListener != null) {
            onItemClickListener.onItemClick(view, (Integer) view.getTag());
        }
    }


    public interface OnItemClickListener {
        void onItemClick(View view, int position);
    }

}