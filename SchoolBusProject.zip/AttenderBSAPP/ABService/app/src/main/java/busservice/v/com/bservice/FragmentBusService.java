package busservice.vv.com.bservice;

import android.Manifest;
import android.app.AlertDialog;
import android.app.Fragment;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.content.DialogInterface;
import android.content.pm.PackageManager;
import android.location.Location;
import android.os.Bundle;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.telephony.SmsManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.couchbase.lite.CouchbaseLiteException;
import com.couchbase.lite.Database;
import com.couchbase.lite.util.Log;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.location.LocationServices;

import java.util.Map;

import busservice.vv.com.bservice.db.Application;
import busservice.vv.com.bservice.db.Student;


public class FragmentBusService extends Fragment implements View.OnClickListener {

    private static final int MY_PERMISSIONS_REQUEST_SEND_SMS = 0;
    private static final int MY_PERMISSIONS_REQUEST_GET_LOCATION = 1;
    private int currentStop = 1;
    private boolean[] attendance;
    private String students[];
    private Map<String, String> studList;
    private Location mLastLocation;
    private String mLatitude;
    private String mLongitude;
    private GoogleApiClient mGoogleApiClient;

    public FragmentBusService() {
        // Required empty public constructor

    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_bus, container, false);
    }


    @Override
    public void onDetach() {
        super.onDetach();
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        mGoogleApiClient = GoogleClient.getInstance(getActivity());

        TextView settingTV = (TextView) view.findViewById(R.id.settingsTitle);
        settingTV.setOnClickListener(this);
        ImageView settingIV = (ImageView) view.findViewById(R.id.settingsImg);
        settingIV.setOnClickListener(this);

        TextView sendNotificationsTitleTV = (TextView) view.findViewById(R.id.sendNotificationsTitle);
        sendNotificationsTitleTV.setOnClickListener(this);
        ImageView sendNotificationsIV = (ImageView) view.findViewById(R.id.sendNotificationImg);
        sendNotificationsIV.setOnClickListener(this);

        TextView sosTitleTV = (TextView) view.findViewById(R.id.sosTitle);
        sosTitleTV.setOnClickListener(this);
        ImageView sosIV = (ImageView) view.findViewById(R.id.sosImg);
        sosIV.setOnClickListener(this);

        TextView attendanceTitle = (TextView) view.findViewById(R.id.attendanceTitle);
        attendanceTitle.setOnClickListener(this);
        ImageView attendanceIV = (ImageView) view.findViewById(R.id.attendanceImg);
        attendanceIV.setOnClickListener(this);

        studList = Student.getStudentsMap(getDatabase());
        students = new String[studList.size()];
        attendance = new boolean[studList.size()];
        int i = 0;
        for (Map.Entry<String, String> studEntry : studList.entrySet()) {
            students[i] = studEntry.getKey();
            i++;
        }

    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.settingsImg:
            case R.id.settingsTitle:
                FragmentManager fragmentManager = getFragmentManager();
                FragmentTransaction fts = fragmentManager.beginTransaction();
                fts.addToBackStack("servicToSettings");
                fts.replace(R.id.content, new SettingsFragment());
                fts.commit();
                break;

            case R.id.sendNotificationsTitle:
            case R.id.sendNotificationImg:
                if (currentStop < 5) {
                    requestSMSPermission(++currentStop);
                } else {
                    currentStop = 1;
                    requestSMSPermission(++currentStop);
                }
                break;

            case R.id.sosTitle:
            case R.id.sosImg:
                requestSMSPermission();
                break;

            case R.id.attendanceTitle:
            case R.id.attendanceImg:
                AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
                builder.setTitle("Mark Attendance")
                        .setMultiChoiceItems(students, attendance, new DialogInterface.OnMultiChoiceClickListener() {

                            @Override
                            public void onClick(DialogInterface dialogInterface, int which, boolean isChecked) {
                                attendance[which] = isChecked;
                            }
                        }).setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int id) {
                        for (int i = 0; i < attendance.length; i++) {
                            if (attendance[i]) {
                                try {
                                    Student.updateStudentAttendance(getDatabase(), studList.get(students[i]));
                                } catch (CouchbaseLiteException e) {
                                    Log.e(Application.TAG, "Cannot add attendance", e);
                                }
                            }
                        }
                    }
                })/*.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int id) {
                                attendance[which]=isChecked;
                            }
                        })*/;


                        /*.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                            }
                        })
                        .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                            }
                        });*/
                builder.create().show();
                break;
        }


       /* FragmentManager fragmentManager = getFragmentManager();
        FragmentTransaction fts = fragmentManager.beginTransaction();
        fts.addToBackStack("servicSettings");
        fts.replace(R.id.fragment_bus, new FragmentSettings());
        fts.commit();*/
    }


    private void requestSMSPermission() {
        if (ContextCompat.checkSelfPermission(getActivity(), Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(getActivity(), new String[]{Manifest.permission.SEND_SMS}, MY_PERMISSIONS_REQUEST_SEND_SMS);
            return;
        }
        sendSMS();

    }

    private void requestSMSPermission(int stopNumber) {
        if (ContextCompat.checkSelfPermission(getActivity(), Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(getActivity(), new String[]{Manifest.permission.SEND_SMS}, MY_PERMISSIONS_REQUEST_SEND_SMS);
            return;
        }
        sendSMS(stopNumber);

    }

    private void sendSMS() {
        String temp = ":";
        for (String phNumber : Student.getStudentParentNum(getDatabase())) {
            Toast.makeText(getActivity(), "Sent Msg to " + phNumber, Toast.LENGTH_LONG).show();
            getLocation();
            temp += phNumber + ":";
                String msg = "Bus Delayed due to Traffic."+
                        "/n"+
                        "Latitude:"+mLatitude+
                        "/n"+
                        "Longitude:"+mLongitude;
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(phNumber, null, msg, null, null);
        }
        createBuilder(temp);
    }


    private void sendSMS(int stopNumber) {
        String temp = ":";
        for (String phNumber : Student.getStudentParentNum(getDatabase(), "Stop " + stopNumber)) {
            Toast.makeText(getActivity(), "Sent Msg to " + phNumber, Toast.LENGTH_LONG).show();
            getLocation();
            temp += phNumber + ":";
            String msg = "Bus arriving to "+stopNumber+
                    "\n"+
                    "Latitude:"+mLatitude+
                    "\n"+
                    "Longitude:"+mLongitude;
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(phNumber, null, msg, null, null);
        }
        createBuilder(temp);
    }
    public void getLocation() {
        if (ContextCompat.checkSelfPermission(getActivity(),Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED
                && ContextCompat.checkSelfPermission(getActivity(),Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(getActivity(), new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, MY_PERMISSIONS_REQUEST_GET_LOCATION);
            return;
        }
        mLastLocation = LocationServices.FusedLocationApi.getLastLocation(mGoogleApiClient);
        if (mLastLocation != null) {
            mLatitude = String.valueOf(mLastLocation.getLatitude());
            mLongitude = String.valueOf(mLastLocation.getLongitude());
        }
    }

    private Database getDatabase() {
        Application application = (Application) getActivity().getApplication();
        return application.getDatabase();
    }

    private void createBuilder(String temp){
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        builder.setMessage("Message sent to - " + temp)
                .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                    }
                })
                .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                    }
                });
        builder.create().show();
    }


    @Override
    public void onStart() {
        mGoogleApiClient.connect();
        super.onStart();
    }

    @Override
    public void onStop() {
        mGoogleApiClient.disconnect();
        super.onStop();
    }

}
