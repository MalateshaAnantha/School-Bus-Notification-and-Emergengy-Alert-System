package busservice.vv.com.bservice.db;

import com.couchbase.lite.CouchbaseLiteException;
import com.couchbase.lite.Database;
import com.couchbase.lite.Document;
import com.couchbase.lite.Emitter;
import com.couchbase.lite.Mapper;
import com.couchbase.lite.Query;
import com.couchbase.lite.QueryEnumerator;
import com.couchbase.lite.util.Log;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Map;

public class Bus {
    private static final String VIEW_NAME = "bus";
    private static final String DOC_TYPE = "bus";

    public static Query getQuery(Database database) {
        com.couchbase.lite.View view = database.getView(VIEW_NAME);
        if (view.getMap() == null) {
            Mapper mapper = new Mapper() {
                public void map(Map<String, Object> document, Emitter emitter) {
                    String type = (String)document.get("type");
                    if (DOC_TYPE.equals(type)) {
                        emitter.emit(document.get("bus_ph_number"), document);
                    }
                }
            };
            view.setMap(mapper, "1");
        }

        Query query = view.createQuery();
        query.setDescending(true);
        return query;
    }

    public static Document addBus(Database database,
                                           String busPhNum) throws CouchbaseLiteException {
        SimpleDateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
        Calendar calendar = GregorianCalendar.getInstance();
        String currentTimeString = dateFormatter.format(calendar.getTime());

        Map<String, Object> properties = new HashMap<String, Object>();
        properties.put("type", DOC_TYPE); //student
        properties.put("bus_ph_number", busPhNum); //35354435
        properties.put("created_at", currentTimeString); //some time
        properties.put("route_num", "1");


        Document document = database.createDocument();
        document.putProperties(properties);

        Log.d(Application.TAG, "Created doc: %s", document.getId());

        return document;
    }

    public static void removeBus(Document bus) throws CouchbaseLiteException {
        Log.d(Application.TAG, "Deleted doc: %s", bus.getId());
        bus.delete();
    }

    public static boolean updateBusNumber(Database database, String busPhNum)
            throws CouchbaseLiteException {
        QueryEnumerator enumerator = getQuery(database).run();
        if(enumerator.getCount()>0){
            Document bus = enumerator.getRow(0).getDocument();
            Map<String, Object> properties = new HashMap<String, Object>();
            properties.putAll(bus.getProperties());
            properties.put("bus_ph_number", busPhNum);
            bus.putProperties(properties);
            return true;
        }else{
            return false;
        }
    }


}
