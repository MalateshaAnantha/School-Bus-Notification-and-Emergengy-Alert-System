package busservice.vv.com.bservice;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.pm.PackageManager;
import android.location.Location;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.telephony.PhoneStateListener;
import android.telephony.SmsManager;
import android.telephony.TelephonyManager;
import android.widget.Toast;

import com.android.internal.telephony.ITelephony;
import com.couchbase.lite.Database;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.location.LocationServices;

import java.lang.reflect.Method;
import java.util.List;

import busservice.vv.com.bservice.db.Application;
import busservice.vv.com.bservice.db.Student;

public class CustomPhoneStateListener extends PhoneStateListener {
    private static final int MY_PERMISSIONS_REQUEST_GET_LOCATION = 1;
    private GoogleApiClient mGoogleApiClient;
    Context context;
    private static final int MY_PERMISSIONS_REQUEST_SEND_SMS = 0;
    private Location mLastLocation;
    private String mLatitude;
    private String mLongitude;

    public CustomPhoneStateListener(final Context context) {
        super();
        this.context = context;
        mGoogleApiClient = GoogleClient.getInstance(context);
    }

    @Override
    public void onCallStateChanged(int state, String callingNumber)
    {
        super.onCallStateChanged(state, callingNumber);
        switch (state) {
            case TelephonyManager.CALL_STATE_IDLE:
                break;
            case TelephonyManager.CALL_STATE_OFFHOOK:
                //handle out going call
                endCallIfBlocked(callingNumber);
                break;
            case TelephonyManager.CALL_STATE_RINGING:
                //handle in coming call
                endCallIfBlocked(callingNumber);
                break;
            default:
                break;
        }
    }

    private void endCallIfBlocked(String callingNumber) {
        try {


            List<String> numList= Student.getStudentParentNum(getDatabase());
            if(numList.contains(callingNumber)){
                // Java reflection to gain access to TelephonyManager's
                // ITelephony getter
                mGoogleApiClient.connect();
                boolean con = mGoogleApiClient.isConnected();
                TelephonyManager tm = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);
                Class<?> c = Class.forName(tm.getClass().getName());
                Method m = c.getDeclaredMethod("getITelephony");
                m.setAccessible(true);
                ITelephony telephonyService = (ITelephony) m.invoke(tm);
                //
                telephonyService.silenceRinger();
                telephonyService.endCall();

                requestSMSPermission(callingNumber);
                mGoogleApiClient.disconnect();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private Database getDatabase() {
        Application application = (Application) ((Activity)context).getApplication();
        return application.getDatabase();
    }

    private void requestSMSPermission(String callingNumber) {
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions((Activity) context, new String[]{Manifest.permission.SEND_SMS}, MY_PERMISSIONS_REQUEST_SEND_SMS);
            return;
        }
        sendSMS(callingNumber);
    }

    private void sendSMS(String callingNumber) {
        String temp = ":";
            Toast.makeText(context, "Sent Msg to " + callingNumber, Toast.LENGTH_LONG).show();
            getLocation();
            temp += callingNumber + ":";
            String msg = "Bus Delayed due to Traffic."+
                    "/n"+
                    "Latitude:"+mLatitude+
                    "/n"+
                    "Longitude:"+mLongitude;
            SmsManager smsManager = SmsManager.getDefault();
        smsManager.sendTextMessage(callingNumber, null, msg, null, null);
    }

    public void getLocation() {
        if (ContextCompat.checkSelfPermission(context,Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED
                && ContextCompat.checkSelfPermission(context,Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions((Activity) context, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, MY_PERMISSIONS_REQUEST_GET_LOCATION);
            return;
        }

        mLastLocation = LocationServices.FusedLocationApi.getLastLocation(mGoogleApiClient);
        if (mLastLocation != null) {
            mLatitude = String.valueOf(mLastLocation.getLatitude());
            mLongitude = String.valueOf(mLastLocation.getLongitude());
        }
    }
}
